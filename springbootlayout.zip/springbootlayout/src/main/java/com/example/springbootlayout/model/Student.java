package com.example.springbootlayout.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
//ระบุ Table
@Table(name="tb_student") 
//ตรวจสอบความเปลี่ยนแปลงที่เกิดขึ้นใน class นี้
@EntityListeners(AuditingEntityListener.class)
public class Student {

    public Student() {

    }


    //การสร้างคอลัมน์ในตาราง

    // 1 คอลัมน์/Field 
    //ใส่ @ แสดงว่าเป็น PK
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", length = 5)
    private int id;

    @Column(name="fname", length = 50)
    private String fname;

    @Column(name="lname", length = 50)
    private String lname;

    @Column(name="email", length = 50)
    private String email;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}