package com.example.springbootlayout.controller;

import com.example.springbootlayout.model.Student;
import com.example.springbootlayout.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BackendController {

    //call service
    @Autowired
    private StudentService stdService;
    
    
    @GetMapping(value = "/backend/dashboard")
    public String dashboard(){ 
        return "backend/dashboard";  
    }

    @GetMapping(value = "/backend/student")
    public String student(){ 
        return "backend/student";  
    }

    @GetMapping(value = "/backend/newstudent")
    public String newstudent(ModelMap model){ 
        Student student = new Student();
        model.addAttribute("student",student);
        return "backend/newstudent";  
    }

    //Add Student
    @PostMapping("/backend/saveStudent")
    public String saveStudent(
        @Validated Student student,
        BindingResult result,
        RedirectAttributes redirectAttributes){
            if(result.hasErrors()){
                return "/backend/newstudent";
            } else {
                //บันทึกข้อมูลสำเร็จ
                stdService.save(student);
                return "redirect:/backend/student";
            }
        }
   
}
