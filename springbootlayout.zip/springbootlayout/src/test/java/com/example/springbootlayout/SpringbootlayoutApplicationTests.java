package com.example.springbootlayout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootlayoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
