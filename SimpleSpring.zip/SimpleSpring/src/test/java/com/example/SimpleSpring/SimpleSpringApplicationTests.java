package com.example.SimpleSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
