package com.example.quickblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
